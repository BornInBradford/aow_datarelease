Lookup table for UK postcodes to OA, LSOA, MSOA and Local authorities, as of November 2022. Uses 2011 census boundaries.  This the most recent (and final) lookup for the 2011 census boundaries. Using the lookup for 2011 boundaries as IMD is only produced using 2011 boundaries  

Downloaded from:https://geoportal.statistics.gov.uk/datasets/9c5ebee4163d435aa4defdaf348ba3c2/about
Download date: 14/02/2024